import { AfterContentInit, Component, OnDestroy, OnInit } from '@angular/core';
import { Post } from 'src/app/classes/post';
import { AuthService } from 'src/app/services/auth.service';
import { LoadscriptsService } from 'src/app/services/loadscripts.service';
import { environment } from 'src/environments/environment';
import { BlogsService } from '../../service/blogs.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy, AfterContentInit {

  apiUrl = environment.apiUrl;

  imageUrl = this.apiUrl + 'images/blogs/';

  homePosts!: Post[];

  showBanner = false;

  totalBlogsNow = 0;

  defaultBlogImage = '../../'

  constructor(public blogService: BlogsService,public auth: AuthService, private loadScript: LoadscriptsService) { }

  ngOnInit(): void {
    this.getHomePopularBlogs()
    // setTimeout(() => {
    // this.showBanner = true;
    this.loadScript.loadScript('/assets/js/slick.min.js', 'slickslider');
    this.loadScript.loadScript('/assets/js/home_slider.js', 'home_slider');
    // }, 5000);
  }

  async getHomePopularBlogs() {
    // this.blogService.getHomeRecentBlogs(10);
    this.auth._homeBlogs.subscribe((data: any[]) => {
      if(data) {
        console.log(data)
        this.homePosts = data;
        this.totalBlogsNow = data.length;
      }
    }) 
    // .subscribe((data) => {
    //   console.log(data)
    //   this.homePosts = data;
    //   this.totalBlogsNow = data.length;
    // }

    // (await this.blogService.getHomeRecentBlogs(10)).subscribe((data) => {
    //   console.log(data)
    //   this.homePosts = data;
    //   this.totalBlogsNow = data.length;
    // })
  }
  ngOnDestroy(): void {
    this.loadScript.revomeScriptById('slickslider');
    this.loadScript.revomeScriptById('home_slider');
    this.showBanner = false;
  }

  getPostImage(postImage?) {
    if (postImage) {
      return this.apiUrl + 'images/blogs/' + postImage
    } else {
      return '../../../../assets/img/defaults/default_thumb.png';
    }
  }

  ngAfterContentInit() {
  }
}
